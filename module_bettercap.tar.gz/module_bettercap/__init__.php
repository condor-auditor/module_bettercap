<?php 
/* 
#proyecto CONDOR es una herramienta de auditoría de red inalámbrica.
#Autor: Samir Sanchez Garnica (by:sasaga)
#twitter @sasaga92
#
#
#

#    Copyright (C) <2017>  <samir sanchez garnica>

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/ 

$module_name="module_bettercap";
$path_bin_bettercap = "bettercap";
$module_version = "1.0";
$module_version_software  ="https://raw.githubusercontent.com/condor-auditor/".$module_name."/master/version";
$path_module_dowload = "https://github.com/condor-auditor/".$module_name.".git";
$module_author = "@sasaga92";
$module_contact = "ssanchezga@ufpso.edu.co";
$path_module_bettercap = "/usr/share/lighttpd/condor/www/modules/".$module_name;
$path_log_directory_bettercap = $path_module_bettercap."/logs/";
$path_log_directory_compress_bettercap = $path_log_directory_bettercap."compress/";
$path_log_bettercap = $path_log_directory_bettercap."bettercap.log";
$path_log_list_connect = $path_module_bettercap."/logs/list_connect.txt";
$path_log_bettercap_command_pid = $path_module_bettercap."/logs/command_pid.log";
$path_log_service_running = "/usr/share/lighttpd/condor/logs/SERVICES_RUNNING";
$path_ip_forward = "/proc/sys/net/ipv4/ip_forward";
$path_base = BASE."/modules/".$module_name;
$module_description = " bettercap es un interceptor/sniffer/registrador para LANs con switch. Soporta direcciones activas y pasivas de varios protocolos (incluso aquellos cifrados, como SSH y HTTPS).
						También hace posible la inyección de datos en una conexión establecida y filtrado al vuelo aun manteniendo la conexión sincronizada gracias a su poder para establecer un Ataque Man-in-the-middle(Spoofing).
						Muchos modos de sniffing fueron implementados para darnos un conjunto de herramientas poderoso y completo de sniffing. ";

$link_pag_oficial_bettercap = "https://bettercap.github.io/bettercap/";
$link_tutorial_bettercap = "https://www.youtube.com/embed/ST1-XZhWADo";
$link_dowload_project = "https://bettercap.github.io/bettercap/downloads.html";
?>
